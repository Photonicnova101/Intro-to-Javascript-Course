/* hw4.js  */

// your solution here
window.addEventListener('load',function(){
    var button = document.getElementById("divideTranscript");
    var processed = 0

    if (processed == 0){
        button.onclick = function(){
            
            var text = document.getElementById("transcriptText").innerHTML;
            var textArr = text.split(' ');
            console.log(text);
            document.getElementById("transcriptText").innerHTML = "";
            console.log(text);
            var transcriptDiv = document.getElementById("transcriptText");
            for (let i=0; i<textArr.length;i++){
                if (textArr[i].length > 0) {
                    
                    var newText = document.createTextNode(textArr[i] + " ");
                    var newSpan = document.createElement("span");
                    newSpan.appendChild(newText);
                    transcriptDiv.append(newSpan);
                    
                }
            }
            var spans = transcriptDiv.getElementsByTagName("span")
            for (let x=0;x<spans.length;x++){
                spans[x].onmouseover = function(){
                    spans[x].style.backgroundColor = "blue"
                }
            }

        }
        processed++;
    }
})
